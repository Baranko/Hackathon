package hackaton;
import java.awt.Image;

public class GOD {
	
	private int clas;
	private int pos = 1;
	private int res = 100;
	private Image dvd;
	private int pow = 100;
	private int exp;
	private int dgr;
	private int lvl = 1;
	private int hod = 1;
	private String name;
	private int edd;
	private int prihodpos;
	private int prihodres;
	private int prihodpow;
	private int prihodexp;
	
	private int maxh = 0; //Hrami
	private int maxs = 0; //Ambari
	private int maxp = 0; //Pamyatniki
	
	//kolvo prispeshnikov na territorii
	private int vi1 = 1; 
	private int vi2;
	private int vi3;
	private int vi4;
	private int vi5;
	private int vi6;
	
	//vliyanie na territorii 
	private double ch1 = 1;
	private double ch2 = 1;
	private double ch3 = 1;
	private double ch4 = 1;
	private double ch5 = 1;
	private double ch6 = 1;

	public void SetClas(int clas){this.clas = clas;}
	public int GetClas(){return clas;}
	
	public void SetPos(int pos){this.pos = pos;}
	public int GetPos(){return pos;}
	
	public void SetRes(int res){this.res = res;}
	public int GetRes(){return res;}
	
	public void SetDvd(Image dvd){this.dvd = dvd;}
	public Image GetDvd(){return dvd;}
	
	public void SetPow(int pow){this.pow = pow;}
	public int GetPow(){return pow;}
	
	public void SetExp(int exp){this.exp = exp;}
	public int GetExp(){return exp;}
	
	public void SetDgr(int dgr){this.dgr = dgr;}
	public int GetDgr(){return dgr;}
	
	public void SetLvl(int lvl){this.lvl = lvl;}
	public int GetLvl(){return lvl;}
	
	public void SetHod(int hod){this.hod = hod;}
	public int GetHod(){return hod;}
	
	public void SetName(String name){this.name = name;}
	public String GetName(){return name;}
	
	public void SetEdd(int edd){this.edd = edd;}
	public int GetEdd(){return edd;}
	
	public void SetPrihodPos(int prihodpos){this.prihodpos = prihodpos;}
	public int GetPrihodPos(){return prihodpos;}
	
	public void SetPrihodRes(int prihodres){this.prihodres = prihodres;}
	public int GetPrihodRes(){return prihodres;}
	
	public void SetPrihodPow(int prihodpow){this.prihodpow = prihodpow;}
	public int GetPrihodPow(){return prihodpow;}
	
	public void SetPrihodExp(int prihodexp){this.prihodexp = prihodexp;}
	public int GetPrihodExp(){return prihodexp;}
	
	//Postroiki
	public void SetMaxh(int maxh){this.maxh = maxh;}
	public int GetMaxh(){return maxh;}
	
	public void SetMaxs(int maxs){this.maxs = maxs;}
	public int GetMaxs(){return maxs;}
	
	public void SetMaxp(int maxp){this.maxp = maxp;}
	public int GetMaxp(){return maxp;}
	
	//Territoriya
	public void SetVi1(int vi1){this.vi1 = vi1;}
	public int GetVi1(){return vi1;}
	
	public void SetVi2(int vi2){this.vi2 = vi2;}
	public int GetVi2(){return vi2;}
	
	public void SetVi3(int vi3){this.vi3 = vi3;}
	public int GetVi3(){return vi3;}
	
	public void SetVi4(int vi4){this.vi4 = vi4;}
	public int GetVi4(){return vi4;}
	
	public void SetVi5(int vi5){this.vi5 = vi5;}
	public int GetVi5(){return vi5;}
	
	public void SetVi6(int vi6){this.vi6 = vi6;}
	public int GetVi6(){return vi6;}
	
	public void SetCh1(double d){this.ch1 = d;}
	public double GetCh1(){return ch1;}
	
	public void SetCh2(double ch2){this.ch2 = ch2;}
	public double GetCh2(){return ch2;}
	
	public void SetCh3(double ch3){this.ch3 = ch3;}
	public double GetCh3(){return ch3;}
	
	public void SetCh4(double ch4){this.ch4 = ch4;}
	public double GetCh4(){return ch4;}
	
	public void SetCh5(double ch5){this.ch5 = ch5;}
	public double GetCh5(){return ch5;}
	
	public void SetCh6(double ch6){this.ch6 = ch6;}
	public double GetCh6(){return ch6;}
}
