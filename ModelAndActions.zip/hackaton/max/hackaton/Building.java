package hackaton;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Building extends JFrame{
	
	static GOD god = new GOD();
	static JButton JHram = new JButton();
	static JButton JAmbar = new JButton();
	static JButton JMemory = new JButton();
	
	public Building()
	{
		this.setSize(500, 500);
		this.getContentPane().setLayout(null);
		//this.add(getJHram());
		//this.add(getJAmbar());
		//this.add(getJMemory());
		this.setTitle("Test JFrame");
	}
	
	//Dobavlenie hramov
	private static JButton getJHram() 
	{
		JHram.setBounds(0, 133, 300, 27);
		JHram.setText("Hram");
		JHram.addActionListener(new HramPlus());
		return JHram;
	}
	static class HramPlus implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			if ((god.GetMaxh()<3)&&(god.GetRes()>0)) //Rabotaet, elsi hramov < 3 i resursov >=50
			{
				god.SetMaxh(god.GetMaxh()+1); //Dobavlyaet 1 hram
				god.SetPrihodPos(god.GetPrihodPos() + 2); //Dobavlyaet prihod poslyshnikov na 2
				god.SetPrihodPow(god.GetPrihodPow() + 2); //Dobavlyaet prihod moshi na 2
				god.SetRes(god.GetRes() - 50); //Zabiraet 50 resursov
			}
		}
	}
	
	//Dobavlenie ambarov
	private static JButton getJAmbar() 
	{
		JAmbar.setBounds(0, 133, 300, 27);
		JAmbar.setText("Ambary");
		JHram.addActionListener(new AmbarPlus());
		return JAmbar;
	}
	static class AmbarPlus implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			if ((god.GetMaxs()<3)&&(god.GetRes()>0)) //Rabotaet, elsi ambarov < 3 i resursov >=50
			{
				god.SetMaxs(god.GetMaxs()+1); //Dobavlyaet 1 ambar
				god.SetPrihodRes(god.GetPrihodRes() + 3); //Dobavlyaet prihod resursov na 3
				god.SetRes(god.GetRes() - 50); //Zabiraet 50 resursov
			}
		}
	}
	
	//Dobavlenie pamyatnikov
	private static JButton getJMemory() 
	{
		JMemory.setBounds(0, 133, 300, 27);
		JMemory.setText("Pamyatniki");
		JMemory.addActionListener(new MemoryPlus());
		return JMemory;
	}
	static class MemoryPlus implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			if ((god.GetMaxp()<3)&&(god.GetRes()>0)) //Rabotaet, elsi pamyatnikov < 3 i resursov >=50
			{
				god.SetMaxp(god.GetMaxp()+1); //Dobavlyaet 1 pamyatnik
				//Dobavlyaet vliyanie na territorii na 0.1
				god.SetCh1(god.GetCh1() + 0.1);
				god.SetCh2(god.GetCh2() + 0.1);
				god.SetCh3(god.GetCh3() + 0.1);
				god.SetCh4(god.GetCh4() + 0.1);
				god.SetCh5(god.GetCh5() + 0.1);
				god.SetCh6(god.GetCh6() + 0.1);
				god.SetRes(god.GetRes() - 50); //Zabiraet 50 resursov
			}
		}
	}

	public static void main(String[] args) 
	{
		Building build = new Building();
		build.setVisible(true);
	}

	
	

}

